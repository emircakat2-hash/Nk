/* Stage 35 — MediaPipe inference must remain outside the UI thread. */
const fs=require('fs'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const worker=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/mediapipe-worker.js'),'utf8');
const checks=[
  ['worker asset exists',worker.length>1000],
  ['UI creates dedicated worker',html.includes("new Worker(workerUrl)")],
  ['transferable ImageBitmap frames',html.includes('createImageBitmap(v)')&&html.includes('[bitmap]')],
  ['main thread has no MediaPipe inference',!html.includes('detectForVideo(')],
  ['worker owns MediaPipe inference',worker.includes('landmarker.detectForVideo(bitmap,m.timestamp)')],
  ['worker tries GPU before CPU',worker.includes("['GPU','CPU']")],
  ['worker supports cached local files',worker.includes('moduleFromFiles(m.files)')],
  ['worker supports remote package fallback',worker.includes('moduleFromRemote(m.bases||[])')],
  ['one in-flight frame prevents backlog',html.includes('if(this.workerBusy)return;')],
  ['worker is terminated on stop',html.includes('this.worker.terminate()')],
  ['camera stream is not sent to worker',!/postMessage\(\{type:\s*['\"]camera/.test(html)],
  ['adaptive inference cadence is retained',html.includes('this.ema>35')&&html.includes('this.iv=80')]
];
let failed=0;
for(const [name,ok] of checks){console.log((ok?'PASS ':'FAIL ')+name);if(!ok)failed++}
if(failed)process.exit(1);
console.log('mediapipe-worker.test.js: '+checks.length+' checks passed');