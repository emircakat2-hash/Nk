/* El çizimi (Hand.paint) performans testi: index.html içindeki gerçek paint() fonksiyonunu
   çıkarıp sahte (mock) bir 2D canvas context ile çalıştırır, çizim çağrısı sayısını sayar.
   Çalıştır: node tools/handpaint.test.js
   NOT: bu sentetik bir Node denemesidir; gerçek cihazda kare hızı ölçümü ayrıca yapılmalıdır. */
const fs=require('fs'),path=require('path'),assert=require('assert');
const html=fs.readFileSync(path.join(__dirname,'..','app/src/main/assets/index.html'),'utf8');
const cut=(a,b)=>{const i=html.indexOf(a),j=html.indexOf(b,i);assert(i>=0&&j>i,'bulunamadı: '+a);return html.slice(i,j)};

let pass=0;const ok=(c,m)=>{assert(c,m);pass++};

/* --- kaynak kontrolü --- */
ok(/FW=this\.FW\|\|\(this\.FW=\.207\)/.test(html),'FW artık tek bir sayı: 5 parmak için ortak genişlik');
ok(!/FW\|\|\(this\.FW=\[\[\.30,\.27,\.23\]/.test(html),'eski 3 parçalı FW tablosu kalmadı');
ok(!/FW=\[\.267,\.200,\.210,\.190,\.170\]/.test(html)&&!/FW=\[\.267,\.1925\]/.test(html),'önceki (stage25/26 ara) FW dizileri kalmadı');
ok(/for\(let f=0;f<5;f\+\+\)\{const c=CH\[f\];x\.moveTo/.test(html),'5 parmağın tamamı tek path içinde birleştirilmiş');
ok(/if\(!this\.lite\)\{/.test(cut('paint(x,g,X,Y,pinch,cursor){','Elin arkasını bulanıklaştır')),'lite modda üçüncü (parlaklık) geçiş atlanıyor');
ok(/_X:new Float64Array\(21\),_Y:new Float64Array\(21\),_cur:\[0,0\]/.test(html),'slotlarda çizim için önceden ayrılmış diziler var');
ok(!/const p=s\.dq,X=p\.map/.test(html),'draw() artık her karede .map() ile yeni dizi üretmiyor');
ok(/this\._PP\|\|\(this\._PP=new Float64Array\(16\)\)/.test(html),'avuç çokgeni artık düz (flat) Float64Array önbellekte');

/* --- fonksiyonel test: gerçek paint() kodunu çalıştırıp çizim çağrısı sayısını say --- */
const body=cut('paint(x,g,X,Y,pinch,cursor){','    },\n    /* Elin arkasını');
const paintFn=new Function('return function paint(x,g,X,Y,pinch,cursor){'+body.slice(body.indexOf('{')+1)+'}')();

function mockCtx(){
  const calls={stroke:0,fill:0,beginPath:0,moveTo:0,lineTo:0,arc:0};
  return new Proxy({lineWidth:1,strokeStyle:'',fillStyle:'',globalCompositeOperation:'',lineCap:'',lineJoin:''},{
    get(t,k){
      if(k in calls)return(...a)=>{calls[k]++};
      if(k==='save'||k==='restore'||k==='closePath')return()=>{};
      if(k==='_calls')return calls;
      return t[k]
    },
    set(t,k,v){t[k]=v;return true}
  })
}

/* 21 sentetik landmark: makul bir el pozu (hepsi sonlu sayı). */
function fakeHand(){
  const X=new Array(21),Y=new Array(21);
  for(let i=0;i<21;i++){X[i]=100+i*3;Y[i]=200+(i%5)*4}
  return{X,Y}
}

{
  const {X,Y}=fakeHand();
  const ctx=mockCtx();
  const self={lite:false};
  paintFn.call(self,ctx,{s:40},X,Y,false,[150,220]);
  const c=ctx._calls;
  // geçiş başına: 1 (5 parmak tek path) + 1 (avuç stroke) = 2 stroke, 1 fill (avuç)
  // masaüstü 3 geçiş (rim/cutout/parlaklık) => 6 stroke + imleç halkası(1) = 7; fill = 3
  ok(c.stroke===7,'masaüstü (lite:false): 7 stroke() çağrısı (ara sürüm: 10, stage25: 19, ilk hâl: 48)  [ölçülen='+c.stroke+']');
  ok(c.fill===3,'masaüstü: 3 fill() çağrısı (yalnızca avuç, geçiş başına 1)  [ölçülen='+c.fill+']');
}
{
  const {X,Y}=fakeHand();
  const ctx=mockCtx();
  const self={lite:true};
  paintFn.call(self,ctx,{s:40},X,Y,true,[150,220]);
  const c=ctx._calls;
  // lite modda 3. (parlaklık) geçiş atlanır: 2 geçiş x 2 stroke = 4 + imleç(1) = 5; çimdik: 2 ekstra fill (parmak uçları)
  ok(c.stroke===5,'mobil (lite:true): 5 stroke() çağrısı (ara sürüm: 7, stage25: 13, ilk hâl: 48)  [ölçülen='+c.stroke+']');
  ok(c.fill===2+2,'mobil+çimdik: avuç (2 geçiş) + çimdik parmak uçları (2) fill  [ölçülen='+c.fill+']');
}
{
  // Koordinatlar bozulmadan (NaN/Infinity yok) geçiyor mu — sadece çizim sayısı azalmış, veri bütünlüğü korunmuş mu?
  const {X,Y}=fakeHand();
  const ctx=mockCtx();
  const self={lite:false};
  assert.doesNotThrow(()=>paintFn.call(self,ctx,{s:40},X,Y,false,[150,220]),'paint() hatasız çalışıyor');
  ok(true,'paint() hatasız çalıştı (NaN/istisna yok)');
}
{
  // _PP flat dizi iki ayrı el çağrısı arasında paylaşılırken veri karışmıyor mu (tek seferde bir el çiziliyor, sorun olmamalı).
  const a=fakeHand(),ctx=mockCtx(),self={lite:false};
  paintFn.call(self,ctx,{s:40},a.X,a.Y,false,null);
  const pp1=Array.from(self._PP);
  const b={X:a.X.map(v=>v+50),Y:a.Y.map(v=>v+50)};
  paintFn.call(self,ctx,{s:40},b.X,b.Y,false,null);
  const pp2=Array.from(self._PP);
  ok(pp1.some((v,i)=>Math.abs(v-pp2[i])>1e-6),'_PP her çağrıda güncelleniyor (eski elin verisiyle karışmıyor)');
}

console.log('El çizimi performans testi: '+pass+' kontrol geçti');
