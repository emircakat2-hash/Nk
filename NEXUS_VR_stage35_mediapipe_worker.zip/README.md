# NEXUS VR (Android)

WebView tabanlı VR masaüstü. Tek Activity + `assets/index.html` (Three.js, WebXR, MediaPipe el takibi).

## Derleme gereksinimleri
| Gereken | Sürüm |
|---|---|
| JDK | **17 veya 21** (Android Studio'nun kendi JBR'si de olur) |
| Android SDK | Platform **34** + Build-Tools **34.0.0** |
| Gradle | 8.7 (wrapper kendisi indirir) |
| İnternet | İlk derlemede bağımlılıklar ve `three.min.js` için |

### Android Studio ile
Klasörü açın → Gradle sync → **Build > Build APK(s)**. SDK ve JDK'yı Studio kendisi kurar.

### Komut satırı
```bash
cp local.properties.example local.properties   # sdk.dir yolunu düzenleyin
./gradlew assembleDebug                         # Windows: gradlew.bat assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```
SDK'yı komut satırından kurmak için:
```bash
sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"
sdkmanager --licenses
```

### Bilgisayarsız / SDK'sız
Projeyi GitHub'a yükleyin; `.github/workflows/build.yml` APK'yı otomatik derler (Actions > Artifacts).

## Güvenlik özeti
- `AndroidBridge` artık oturuma özel rastgele anahtar ister; iframe'deki siteler uygulama listesine erişemez / uygulama başlatamaz.
- Kamera/mikrofon izni yalnızca uygulamanın kendi sayfasına verilir.
- Düz HTTP kapalı (arayüz `http://` adresleri `https://`'e çevirir), karma içerik kısıtlı, dosya/content erişimi kapalı, Safe Browsing açık, SSL hataları reddedilir.
- Proxy: yerel/özel ağ adresleri engelli, yalnızca `X-Frame-Options` ve CSP `frame-ancestors` kaldırılır, `X-Requested-With` sızdırılmaz.
- Ana çerçeve uygulama sayfası dışına gidemez; `index.html` iframe içinde gömülemez.
- Release build hâlâ debug imzalı: yayın için kendi keystore'unuzu ekleyin.

## Mobile hand-tracking performance
- Camera input is capped at 320×240 / 30 FPS on phones and tablets.
- MediaPipe still tracks up to two hands; inference cadence adapts to measured processing time.
- Hand drawing skips costly shadow, crease, and microtexture effects on handheld devices.
- WebGL antialiasing is disabled on handhelds and pixel ratio is capped lower to reduce GPU load.

## Hand model appearance and latency
- Rendered hand and forearm are semi-transparent.
- Hand landmark smoothing has been disabled and the Yumuşatma control removed, reducing perceived movement delay.

## Quest 3 arayüzü
- Dock: koyu kapsül, solda avatar / saat-wifi-pil kapsülü (dokununca **Hızlı ayarlar**) / zil (Tanı) / VR halkası; ortada yuvarlatılmış kare uygulama ikonları, sağda Library düğmesi, altında tutma çubuğu. Dock göze doğru hafif eğik durur.
- Pencereler: Quest'in koyu petrol rengi, başlık üstte ortada, küçült ve kapat sağ üstte, hafif kavisli; "Ön yay" düzeninde yan yana, alt kenarları dock'un üstünde dizilir.
- Library: sol menü (Ara / Uygulamalar / Dünyalar), 3 sütunlu yatay kartlar, "Tümü" ve "Son kullanılan" açılır kutuları, dikey kaydırma.
- Klavye: koyu, yuvarlak tuşlu, mavi Enter; dock'un hemen altında, göze doğru eğik açıyla açılır; dock gizlenmez.
- El / Sensör / VR / Kamera / Düzen / Sıfırla düğmeleri **Hızlı ayarlar** penceresine taşındı (dock'taki saat kapsülüne dokun).

## Son değişiklikler (el, sinema, tarayıcı)
- El: parmaklar boğum boğum incelen, avuç + bilek çokgenli gerçek el silüeti. Dış katman siyah, iç kısım tamamen şeffaf (kamera/arka plan görünür). Çimdikte iki uç parlar. Çıkarım hızı cihaz yüküne göre ayarlanır, sayfa gizliyken ve el yokken seyreltilir.
- Sinema: koltuklar yumuşak kenarlı (köşe renkleriyle gölgelendirilmiş) ve tek geometride birleştirildi (tek çizim çağrısı). Halı/duvar dokuları önbelleğe alındı. Perde gerçek beyaz perde + siyah maskeleme çerçevesi; video yokken beyaz, oynarken siyah zemin.
- Tarayıcı: Quest tarayıcısı gibi sekme şeridi, geri/yenile/adres çubuğu/mikrofon/yer imi/menü. Yer imleri başlangıç sayfasına eklenir. Pencere başlık bandı koyulaştırıldı; renkler ve dock aynı.
- Sinema perdesi 16:9 ve küçültüldü (≈5,4×3 m), göz hizasının üstüne alındı; alt kısmı koltuklarla kapanmaz. Oynarken panel şeffaf, video doğrudan GPU dokusundan (VideoTexture) gelir; yalnızca yeni karede yüklenir. Oynatırken toz efekti durur, el algılama seyrekleşir.


## Stage 16 scroll fix
Normal browser up/down controls target the real browser WebView; URL-based web app panels now have their own up/down controls. See `STAGE16_SCROLL_FIX.md`.


## Stage 17 GORILLA RUN çekirdeği
Dock'ta **Goril** simgesi; dokunmatik test modunda iki elle itiş/tırmanma fiziği. Ayrıntı ve açık eksikler: `STAGE17_GORILLA_CORE.md`.


## Stage 18 Orman kanyonu + gerçek el kontrolü + VR
Özgün low-poly orman kanyonu haritası, gorilla modeli, kamera ile gerçek el takibi (yumruk = tut), WebXR denetleyici desteği ve otomatik kalite. Ayrıntı ve açık eksikler: `STAGE18_FOREST_CANYON.md`.


## Stage 20 Tarayıcı
Çoklu sekme (en çok 5), yer imi listesi (200), geçmiş (100), reklam engelleyici ve PC sürümü; menü (⋮) ve PhoneXR tarzı başlangıç sayfası (Favoriler / Yer imleri / Geçmiş / Ayarlar). Ayrıntı ve açık eksikler: `STAGE20_BROWSER.md`. Test: `node tools/browser.test.js`.


## Stage 21 One Euro düzeltmesi
El imleci ve iskelet süzgeci artık gerçekten hıza uyum sağlıyor (hız el boyuna göre ölçülüyor), `NaN`/zaman boşluğu hataları giderildi. Ayrıntı, ölçümler ve açık eksikler: `STAGE21_ONE_EURO.md`. Test: `node tools/oneeuro.test.js`.


## Stage 22 Sinema odaları
Sinemada **Oda** düğmesiyle Salon / Roblox evi / Gün batımı / Gece / Uzay / Stüdyo / Brawl arena seçilir (`GLBRoom` yükleyici, `roblox_house.glb`). Ayrıntı ve açık eksikler: `STAGE22_ROOMS.md`. Test: `node tools/glbroom.test.js`, `node tools/envsky.test.js`.


## Stage 23 Pencere çubuğu, cam TR klavye, el menüsü
Her pencerenin altında Quest/PhoneXR tarzı hap (başlık sürükle + klavye/büyüt/küçült/kapat), cam görünümlü Türkçe klavye (mavi Enter, ?123 sembol katmanı) ve avuç yüze dönükken açılan el menüsü. Ayrıntı ve açık eksikler: `STAGE23_WINDOW_HAND.md`. Test: `node tools/winhand.test.js`.


## Stage 25 El çizimi performans optimizasyonu
Parmaklar artık ayrı ayrı değil TEK path + TEK stroke() ile (hepsi aynı ortalama genişlikte) çiziliyor; her karede yeni dizi ayırma (hem landmark koordinatları hem avuç çokgeni) kaldırılıp önceden ayrılmış (preallocated) dizilerle değiştirildi. Elde başına canvas çizim çağrısı 48 → **7 (masaüstü) / 5 (mobil)** oldu (~%85-90 azalma). Algılama tarafı (MediaPipe modeli, GPU delegate, kamera limitleri, OneEuro) PhoneXR referans projesiyle karşılaştırıldı ve zaten aynı/doğru desenlerde olduğu görüldü, değiştirilmedi. Ayrıntı: `STAGE25_HAND_PERFORMANCE.md`. Test: `node tools/handpaint.test.js`.


## Stage 26 Windows 7 (VR): netlik, ölçek, el kontrolü
Win7 dokusu artık doğrudan WebView anlık görüntüsünden (1600×686, değişmeyen karede yük yok), arayüz masaüstü boyutlu (CSS 1280) görünüm alanında çalışır, çimdikle pencere sürükleme/tıklama/kaydırma yapılır ve içerideki tarayıcı WebView'leri görüntüye birleştirilir. Ayrıca tüm panellerde düz düğmeler çimdikle tıklanır. Ayrıntı ve açık eksikler: `STAGE26_WIN7_VR.md`. Test: `node tools/w7touch.test.js`.


## Stage 27 GPU tarayıcı
Tarayıcı artık ana ekrana eklenmeyen bir VirtualDisplay içinde (gerçek GPU penceresinde) çalışır; video açılır, pencere dışına taşmaz, kareler arka planda sıkıştırılıp itilir. Win7, oyunlar ve web uygulamaları değişmedi. Ayrıntı ve açık eksikler: `STAGE27_GPU_BROWSER.md`. Test: `node tools/gpubrowser.test.js`.


## Stage 30 iOS ikon teması
Sistem uygulamaları ve web uygulamaları iOS tarzı ikon temasına geçti (11 çizim: Tarayıcı, App Store, Instagram, Discord, Android, YouTube, GitHub, Spotify, WhatsApp, SoundCloud, Vikipedi; diğerleri kendi renk/glifiyle). Katalogda eksik olan **Instagram** ve **SoundCloud** eklendi (26 → 28). Ayrıntı: `STAGE30_ICON_THEME.md`. Test: `node tools/icontheme.test.js`.

## Stage 31 Kısayol çakışması düzeltmesi
«VR başlatılamadı (pcol / length)» hatası giderildi: tarayıcı kısayolları dock sabitlemeleriyle aynı `pins` anahtarını paylaşıyordu; artık `bpins` kullanıyor, eski ayarlar otomatik taşınır. Ayrıntı: `STAGE31_PINS_FIX.md`. Test: `node tools/browser.test.js`.

## Stage 32 App Store
Yeni **App Store** uygulaması: sol menüde bölümler (Öne Çıkan, Tümü, 6 kategori, Yüklenenler, Ara), 40 web uygulaması, **AL** düğmesiyle indirme. İndirmeden önce ve ilk açılışa kadar harf ikonu; **ilk açılışta sitenin kendi ikonu** çekilip uygulamanın ikonu olur (`AndroidBridge.fetchIcon`). App Store ikonu Uygulamalarım'dan buraya taşındı. Ayrıntı ve açık eksikler: `STAGE32_APPSTORE.md`. Test: `node tools/appstore.test.js`.

## Stage 34 Açılış başlatıcı sahnesi
Uygulama açılınca **Nexus VR** başlatıcı sahnesi gelir: Başlat, Ayarlar, Kalibrasyon, VR Ayarları, **El Takibi** anahtarı, Hakkında, Çıkış, Hızlı Erişim ve Tema çalışır; eller açıkken çimdik tıklama yapar. Ayrıntı ve açık eksikler: `STAGE34_LOBBY.md`. Test: `node tools/lobby.test.js`.
