# NEXUS VR — Gaze-control implementation report

## 7. Bakışla WebView etkileşimi — 3. aşama

- `gazeInteractAt()` eklendi. Merkez bakış noktası üstteki görünür gömülü WebView alanına denk gelirse etkileşim Android UI kuyruğuna aktarılır.
- WebView alanının üst kenarına bakışla bekleme, sayfayı yukarı; alt kenarına bakışla bekleme, sayfayı aşağı kaydırır. İç bölgede bekleme normal `ACTION_DOWN`/`ACTION_UP` dokunuşu üretir; bağlantılar, düğmeler ve form alanları WebView tarafından işlenir.
- Yöntem mevcut token doğrulamasını kullanır ve ana uygulamanın birincil WebView'ini hedeflemez; üstten alta değil, en üstteki görünür çocuk WebView seçilir.
- Bu aşamada baş hareketiyle WebView üzerinde sürekli sürükleme/serbest kaydırma ve gerçek WebXR/stereo içindeki yerel WebView katmanları tamamlanmış sayılmaz. Android derlemesi ve fiziksel cihaz testi bu ortamda yapılmadı.


## 7. Aşama 4 — gerçek bakış koordinatını WebView'e iletme

- Önceki aşamada WebView etkileşimi sabit ekran merkezine gönderiliyordu. Bu aşamada Three.js raycast sonucundaki `h.point`, kamera izdüşümüyle ekran koordinatına çevrilir.
- Ekran koordinatları `devicePixelRatio` ile Android overlay'in kullandığı fiziksel piksel ölçeğine dönüştürülür.
- Etkileşim yalnızca izdüşüm görünür viewport sınırları içindeyse gönderilir; token doğrulaması ve üstteki görünür WebView seçimi korunur.
- JavaScript sözdizimi ve ZIP bütünlüğü kontrol edilebilir; Android derlemesi ve gerçek cihaz testi bu ortamda doğrulanmadı.


## 8. Aşama 5 — stereo modda panel içi bakış etkileşimi

- Stereo modunda gizlenen yerel WebView katmanına, paneldeki bakış konumunu normalize edilmiş koordinatlarla aktarmak için `gazeInteractInView()` eklendi. Normal moddaki `gazeInteractAt()` yolu korunur.
- `prepareGazeView()` gizli WebView'i içerik çözünürlüğünde tutar ve sayfanın duraklatılmasını önler; bu sayede stereo görüntüdeki panel yüzeyine bakarak dokunma/kaydırma olayının arka plandaki WebView'e iletilmesi hedeflenir.
- WebView boyutu değişmedikçe hazırlama çağrısı tekrarlanmaz; her karede Android UI kuyruğuna gereksiz iş yollanmasını engellemek için boyut önbelleği eklendi.
- HTML içindeki JavaScript blokları `node --check` ile doğrulandı. Android Gradle derlemesi, VR gözlüğü ve gerçek cihaz testi bu ortamda çalıştırılmadı; bu nedenle stereo etkileşim henüz cihaz üzerinde doğrulanmış kabul edilmemeli.
